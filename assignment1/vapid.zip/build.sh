#!/bin/bash

gcc -o vapid vapid.c
chmod u+x vapid
